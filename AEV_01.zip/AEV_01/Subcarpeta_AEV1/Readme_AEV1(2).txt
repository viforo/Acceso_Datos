Archivo txt de prueba para Actividad Evaluable 1 de Acceso a Daros - Victor Forés 2º DAM



wfmewgwe
ewgewg
wgewrh
r
hre
h



rhgreh
tjhtjtrjjjjjjjtrhgfecverbh
hrehretj
etrgerfv
rc
e
grehtr





rhrrrrrrrrevcerkengjnrwfioenwfkvnr jrbner jvnr
rgnreknhjrenhgkmr jlgnrembh e
v jkerlnbjrenvm
rng orekngm
den