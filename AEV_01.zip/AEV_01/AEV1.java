package AEV_01;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

public class AEV1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String rutafichero = args[0];

		switch (pregunta()) {
		case 1:
			getInformacio(rutafichero);
			break;
		case 2:
			System.out.print("Nom de la nova carpeta: ");
			Scanner nom = new Scanner(System.in);
			String nomCarpeta = nom.nextLine();
			creaCarpeta(nomCarpeta);
			pregunta();
			break;

		case 3:
			System.out.print("Nom del nou fitxer: ");
			Scanner nomF = new Scanner(System.in);
			String nomFitxer = nomF.nextLine();
			crearFitxer(nomFitxer);
			pregunta();
			break;

		case 4:
			//No me funciona, no se per qu�
			System.out.print("Nom del arxiu a eliminar: ");
			Scanner nomE = new Scanner(System.in);
			String nomEliminar = nomE.nextLine();
			elimina(nomEliminar);
			pregunta();
			break;

		case 5:

			System.out.print("Nom del arxiu: ");
			Scanner nomR = new Scanner(System.in);
			String nomRenomenar = nomR.nextLine();
			crearFitxer(nomRenomenar);
			pregunta();
			break;

		default:
			System.out.println("Selecciona una opci� v�lida");
			pregunta();
			break;
		}

	}

	public static int pregunta() {
		int menu;
		do {

			System.out.print(
					"Quina acci� vols realitzar? \n 1.Obtindre informaci� \n 2.Crear carpeta \n 3.Crear fitxer \n 4.Eliminar \n 5.Renomenar \n");

			Scanner teclat = new Scanner(System.in);
			menu = teclat.nextInt();

		} while (menu > 5 || menu < 1);

		return menu;
	}

	public static void getInformacio(String ruta) {

		File carpetaActual = new File("Nuevo_Archivo.txt");

		String[] listaArchivos = carpetaActual.list();

		System.out.println("-------------------------------");
		System.out.println("Informaci�n de " + carpetaActual.getName());

		File fichero = new File("Ejemplo.txt");

		System.out.println("           ");

		if (fichero.isDirectory()) {

			System.out.println("Tipo: DIRECTORIO");
			System.out.println("N�mero de archivos: " + fichero.listFiles());
			System.out.println("Espacio: ");
			System.out.println("\t Total: " + fichero.getTotalSpace());
			System.out.println("\t Libre: " + fichero.getFreeSpace());
			System.out.println("\t Usado: " + fichero.getUsableSpace());

		} else {
			System.out.println("Tipo: FICHERO");
			System.out.println("Tama�o: " + fichero.length());

		}
		System.out.println("Nombre: " + fichero.getName());
		System.out.println("Ruta absoluta: " + fichero.getAbsolutePath());
		System.out.println("�ltima modificaci�n: " + fichero.lastModified());

		if (fichero.isHidden()) {
			System.out.println("Fichero oculto: SI");
		} else {
			System.out.println("Fichero oculto: NO");

		}

		System.out.println("-------------------------------");

	}

	public static void creaCarpeta(String nombre) {

		File carpetaActual = new File(nombre);
		
		boolean exists = carpetaActual.exists();
		if (exists) {
			System.out.println("Ja existeix una carpeta amb el mateix nom \n");
		}else {

			carpetaActual.mkdir();
			System.out.println("S'ha creat la carpeta " + nombre + "\n");
		}
		
	}

	public static void crearFitxer(String nombre) {
		File objetoFile = new File(nombre);
		
		boolean exists = objetoFile.exists();
		if (exists) {
			System.out.println("Ja existeix un arxiu amb el mateix nom \n");
		}else {
			try {
				objetoFile.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("S'ha creat el fitxer " + nombre + "\n");
		}
		
	}

	public static void elimina(String nomObj) {

		File objetoFile = new File(nomObj);
		boolean exists = objetoFile.exists();
		if (exists) {

			if (objetoFile.isDirectory()) {

				if (objetoFile.delete()) {
					System.out.println("S'ha borrat la carpeta: " + objetoFile.getName() + "\n");
				} else {
					System.out.println("Error al eliminar la carpeta. \n");
				}
			} else {
				if (objetoFile.delete()) {
					System.out.println("S'ha borrat el arxiu: " + objetoFile.getName() + "\n");
				} else {
					System.out.println("Error al eliminar el arxiu. \n");
				}
			}
		} else {
			System.out.println("No existeix ning�n arxiu amb el nom: " + objetoFile.getName() + "\n");
		}
	}

	public static void renomena(String nombre) {

		File objetoFile1 = new File(nombre);
		boolean exists = objetoFile1.exists();
		if (exists) {
			
			System.out.print("Introdueix un nom: ");

			Scanner sc = new Scanner(System.in);
			String nom = sc.nextLine();
			File objetoFile2 = new File(nom);
						
			if (objetoFile1.isDirectory()) {

				if (objetoFile1.renameTo(objetoFile2)) {
					System.out.println("Carpeta renombrada correctament. \n");
				} else {
					System.out.println("Error al cambiar de nom la carpeta \n");
				}
			} else {
				if (objetoFile1.renameTo(objetoFile2)) {
					System.out.println("Arxiu renombrat correctament \n");
				} else {
					System.out.println("Error al cambiar de nom el arxiu \n");
				}
			}
		}

	}

}
